# Final Project
## `Delete this readme or write your own version before starting final project`
### `Leave the "Init" (the first) commit`
### `Refer assignment on iLMS` [HERE](http://lms.nthu.edu.tw/course.php?courseID=38045&f=hw&hw=185798)

### Clone from this repository and push to your group's one
### E.g., https://est-latex.sjf.tw/f-0/FinalProject  OR /Playground
